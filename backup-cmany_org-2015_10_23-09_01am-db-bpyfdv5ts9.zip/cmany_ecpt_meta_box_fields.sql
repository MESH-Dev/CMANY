CREATE TABLE `cmany_ecpt_meta_box_fields` (  `id` mediumint(9) NOT NULL AUTO_INCREMENT,  `name` tinytext NOT NULL,  `nicename` tinytext NOT NULL,  `parent` tinytext NOT NULL,  `type` tinytext NOT NULL,  `options` mediumtext NOT NULL,  `description` longtext NOT NULL,  `list_order` tinyint(4) NOT NULL,  `rich_editor` tinyint(4) NOT NULL,  `max` tinyint(4) NOT NULL,  UNIQUE KEY `id` (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `cmany_ecpt_meta_box_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `cmany_ecpt_meta_box_fields` ENABLE KEYS */;
