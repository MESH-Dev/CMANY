CREATE TABLE `cmany_ecpt_meta_boxes` (  `id` mediumint(9) NOT NULL AUTO_INCREMENT,  `name` tinytext NOT NULL,  `nicename` tinytext NOT NULL,  `page` tinytext NOT NULL,  `context` tinytext NOT NULL,  `priority` tinytext NOT NULL,  `post_ids` mediumtext NOT NULL,  UNIQUE KEY `id` (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `cmany_ecpt_meta_boxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `cmany_ecpt_meta_boxes` ENABLE KEYS */;
